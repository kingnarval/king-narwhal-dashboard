import { useEffect, useState } from "react";

export default function Home() {
  const [coins, setCoins] = useState([]);

  useEffect(() => {
    async function load() {
      const res = await fetch("/api/prices");
      const data = await res.json();
      setCoins(data);
    }
    load();
  }, []);

  return (
    <div style={{ fontFamily: "Arial", color: "white", background: "#001F3F", minHeight: "100vh", padding: "2rem" }}>
      <h1>👑 The Tusked Realm Dashboard</h1>
      <p>Live data of memecoins (powered by CoinGecko API)</p>
      <ul>
        {coins.map((c) => (
          <li key={c.id}>
            <img src={c.image} width="25" alt={c.name} style={{ marginRight: "10px" }} />
            <b>{c.name}</b> — ${c.current_price} — Market Cap: ${c.market_cap.toLocaleString()}
          </li>
        ))}
      </ul>
    </div>
  );
}
