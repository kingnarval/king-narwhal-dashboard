export default async function handler(req, res) {
  try {
    const ids = ["dogecoin", "pepe", "bonk", "floki", "shiba-inu"];
    const url = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${ids.join(",")}`;
    const response = await fetch(url);
    const data = await response.json();
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: "Erreur API CoinGecko", details: err });
  }
}
